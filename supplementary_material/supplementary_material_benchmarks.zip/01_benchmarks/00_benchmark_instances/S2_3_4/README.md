
# Reproducibility of the Graph Benchmark Instances

1. Execute `generate_folders.sh`
2. Execute `generate_instances.py`



