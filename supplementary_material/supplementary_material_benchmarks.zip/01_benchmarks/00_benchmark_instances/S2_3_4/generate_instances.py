
import random
import os

from genGraph import gen_graph

path = os.path.join("..","..","02_output","S3-T4","S3-T4_total_time.csv")

with open(path, "r") as f:
    index = 0
    for line in f.readlines():
        if index == 0:
            index += 1
            continue

        splits = line.split(",")
        str_edge_probability = splits[0]
        str_number_vertices = splits[1]
        str_repetition_number = splits[2]
        str_seed = splits[3]

        edge_probability = int(str_edge_probability)
        number_vertices = int(str_number_vertices)
        repetition_number = str(str_repetition_number)
        seed = int(str_seed)

        print(f">>> Now processing: Edge-Probability: {edge_probability}, Number-Vertices: {number_vertices}, Repetition Number: {repetition_number}, Seed: {seed}")

        output_path = os.path.join("graph_instances",str_edge_probability,str_number_vertices,f"{str_repetition_number}.lp")

        random.seed(seed)
        vertices, edges = gen_graph(int(number_vertices), int(edge_probability))

        with open(output_path, "w") as output_file:
            output_file.write(f"seed({int(seed)}).")
            output_file.write(f"num_vertices({int(number_vertices)}).")
            output_file.write(f"edge_probability({int(edge_probability)}).")
            output_file.write(f"repetition({int(repetition_number)}).")

            number_vertices_factor = 0.5
            output_file.write(f"min_reached_vertices({int(len(vertices) * number_vertices_factor)}).")

            for vertex in vertices:
                output_file.write(vertex)

            for edge in edges:
                output_file.write(edge)

    index += 1


