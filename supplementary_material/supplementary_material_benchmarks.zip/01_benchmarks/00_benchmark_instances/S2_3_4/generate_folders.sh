FOLDER=graph_instances
mkdir ./$FOLDER

for prob in `seq -w 010 10 100`
do
    mkdir ./$FOLDER/$prob
        for vertices in `seq -w 010 10 350`
        do
        mkdir ./$FOLDER/$prob/$vertices
        done
done


