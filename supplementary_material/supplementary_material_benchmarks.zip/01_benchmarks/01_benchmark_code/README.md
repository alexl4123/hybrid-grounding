
# How to make benchmarks runable?

Read reproducibility checklist (`README.md` from `01_benchmarks`).

