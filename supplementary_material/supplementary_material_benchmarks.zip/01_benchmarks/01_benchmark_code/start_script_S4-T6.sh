#!/bin/bash
PROBLEM=S4-T6
MYPATH=instances/${PROBLEM}

nohup <YOUR_PATH>start_benchmark_tests.py ${MYPATH} ${PROBLEM}  &> ${PROBLEM}.log &

