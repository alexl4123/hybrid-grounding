#!/bin/bash
PROBLEM=S1
MYPATH=instances/${PROBLEM}

nohup <YOUR_PATH>/start_benchmark_tests.py ${MYPATH} ${PROBLEM}  &> ${PROBLEM}.log &

