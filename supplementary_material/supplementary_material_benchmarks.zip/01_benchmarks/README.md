# Reproducibility Checklist/list

Dear reviewer, we provide you here with our reproducibility checklist.

## Folder Structure

1. In `00_benchmark_instances` you find all benchmark instances, or ways how to generate our benchmark instances respectively.
2. In `01_benchmark_code` you find our benchmark scripts
3. In `02_output` you find our benchmark output

## Reproduce Benchmarks

First note that we assume you to have coding experience in python, or any familiar programming language.
Additionally, we assume you to have a unix-like (preferrably linux) system, as you need to execute several shell scripts.

1. In `00_benchmark_instances` re-generate instances for graph instances (See `01_benchmarks/00_benchmark_instances/S2_3_4/README.md`)
2. Copy paste `01_benchmarks/00_benchmark_instances/S2_3_4/graph_instances` to `01_benchmarks/01_benchmark_code` and same for S1
3. Copy paste all S2-3-4 encodings to `01_benchmarks/01_benchmark_code`
4. Refactor the instances folder (you just pasted), s.t. for each encoding of S2-3-4 it has the structure (e.g., for `S3-T4`): `S3-T4/hg_encoding.lp`,`S3-T4/traditional_encoding.lp`, `S3-T4/010.lp`, ... (for all other graphs) 
5. Copy paste the `nagg` prototype code to `01_benchmark_code`
6. Generate symlinks/runables in the folder `01_benchmark_code` for gringo (`gringo`), clingo (`clingo`), idlv (`idlv.bin`) and python (`python3`)
7. For all (S2-3-4) experiments you want to execute, change paths in `start_script_SX.sh` accordingly
8. In `start_benchmark_tests.py` change programmatically at the bottom of the file (i) rewriting-strategy (RS for S2, S3; RA for S4), (ii) the number of parallel threads (`parallel_threads`) you want to use.
9. For `S1`, further programmatically change the behavior of `start_benchmark_tests.py` s.t. only one file for execution of the benchmarks is enough 
10. Second to last, note that if it does not work, double check your changed paths.


